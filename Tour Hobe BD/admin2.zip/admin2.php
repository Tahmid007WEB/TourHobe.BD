<?php
include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .input-field{
            padding:20px;
            box-size:20px;
            
        }

        input{
  width: 70%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
}
.tour1{
  
  justify-content: center;
  align-items: center;
  text-align:center;
  border: 3px solid #73AD21;
}
        </style>
    <title>ADMIN PANEL</title>
</head>
<body>
    <h1 style="color:black;text-align:center;font-size:20px">
    Welcome To TOURPLANER.COM.BD
    <h2 style="text-align:center"> Admin Panel<h2>
</h1>
<form action="#" class="tour1" method = "post">
            <h2 class="">ADD TOURDESTION PLACE</h2>
            <div class="input-field">
              
              <input type="text" placeholder="ADD TOUR PLACE NAME"  name = "login_user" />
            </div>
            <div class="input-field">
             
              <input type="text" placeholder="ADD YOUTUBE ID 11 CHARACTER"  name = "email"/>
            </div>
            <div class="input-field">
             
              <input type="text" placeholder="ADD DESCRIPTION"  name = "password"/>
            </div>
            <input type="submit" class="btn" value="INSERT" name = "store" />
            <input type="submit" class="btn" value="DELETE" name = "store2" />
            
          </form>

    
</body>
</html>
<?php

if(isset($_POST['store'])){
$use = $_POST['login_user'];
$email = $_POST['email'];
$pass = $_POST['password'];


$query="INSERT INTO videos VALUES ('','$use','$email','$pass')";
$data = mysqli_query($conn,$query);

if($data)
{
  
  echo '<script>alert("Data inserted into database")</script>';
  

}
else{
  
  echo '<script>alert("Failed to insert data in database")</script>';
}
}
if(isset($_POST['store2'])){
    $use = $_POST['login_user'];
    $email = $_POST['email'];
    $pass = $_POST['password'];
    
    
    $query="DELETE FROM videos WHERE name='$use'";
    $data = mysqli_query($conn,$query);
    
    if($data)
    {
      
      echo '<script>alert("Tour Place Delete Sucessful")</script>';
      
    
    }
    else{
      
      echo '<script>alert("Tour Place doesnot found")</script>';
    }
    }


?>